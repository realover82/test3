package egovframework.example.studyGuide.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

public interface StudyGuideService {

	List<EgovMap> selectStudyGuideServiceList() throws Exception;

}
