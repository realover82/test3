package egovframework.example.spritGuide.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

public interface SpritGuideService {

	List<EgovMap> selectSpritGuideServiceList() throws Exception;

}
