package egovframework.example.interStep.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

public interface InterStepService {

	List<EgovMap> selectInterStepServiceList() throws Exception;

}
