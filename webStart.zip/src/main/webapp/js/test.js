///**
// * 
// */
//const what = "nicolas";
//
//console.log(what);